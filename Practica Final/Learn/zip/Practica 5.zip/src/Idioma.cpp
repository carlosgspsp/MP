/** 
 * @file Idioma.cpp
 * @author DECSAI
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include "Bigrama.h"
#include "Idioma.h"

using namespace std;

Idioma::Idioma() {
    _idioma="unkown";
    _conjunto = nullptr;
    _nBigramas = 0;
}

Idioma::Idioma(int nbg)  {
    _conjunto = nullptr;
    reservarMemoria(nbg);
}

void Idioma::liberarMemoria() {
    delete liberarMemoria;
}

string Idioma::getIdioma() const {
    return _idioma;
}

void Idioma::setIdioma(const string& id) {
    _idioma = id;
}

Bigrama Idioma::getPosicion(int p) const {
     return _nBigramas;
}


void Idioma::setPosicion(int p, const Bigrama& bg) {
     _nBigramas=p;
}

bool Idioma::insertarBigrama(const Bigrama& bg){
    // Implementar
}

int Idioma::findBigrama(const char bg[]) const  {
    string::find_first_of bg[];
}
bool Idioma::salvarAFichero(const char *fichero) const {
   // Implementar esta funcion
}

bool Idioma::cargarDeFichero(const char *fichero) {
    // Implementar esta funcion
}

 
void Idioma::reservarMemoria(int n) {
    n = new int;
}
