/** 
 * @file Bigrama.cpp
 * @author DECSAI
*/

#include <cstring>
#include <iostream>
#include <cctype>
#include "Bigrama.h"

using namespace std;


Bigrama::Bigrama() {
    _bigrama[0] = '\0';
    _frecuencia = -1;
}

const char * Bigrama::getBigrama() const {
    return _bigrama;
}
int Bigrama::getFrecuencia() const {
    return _frecuencia;
}

void Bigrama::setBigrama(const char cadena[]) {
    if (strlen(cadena) <= 2)
        strcpy(_bigrama, cadena);
//    strncpy(_bigrama, cadena, 2); // Diferencias, violaciones de _bigrama[] o de cadena[]
}

void Bigrama::setFrecuencia(int frec) {
    _frecuencia = frec;
}

void ordenaAscFrec(Bigrama *v, int n)  {
    int menor = 999999;
    const char *menorp;
    for (Bigrama *k = v; k < v+n; k++)
    {
        for(Bigrama *p = k; p< v+n; p++){
        if (p->getFrecuencia()<menor){
            menor = p->getFrecuencia();
            menorp = p->getBigrama();
        }
        }
        menor = 999999;
        for (Bigrama *i= v+n-1; i<=k; i--)
        {
            *i = *(i-1);
          //  *k->setBigrama(menorp);
        }
        
    }
    
}

void ordenaAscBigr(Bigrama *v, int n) {
    char menor = 'a'+27;
    char menor1 = menor;
    Bigrama *menorp;
    for (Bigrama *k = v; k<v+n; k++)
        
    {
        for (Bigrama *p= k; p<v+n;p++)
        {
            if(tolower(*(p->getBigrama()))< menor)
            {  
            menor = *p->getBigrama();
            for (Bigrama *i= k; i<v+n;i++)
        {
            if(*((i+1)->getBigrama())< menor1)
            {  
            menor1 = *((i+1)->getBigrama());
            }  
            else if (tolower(*(p->getBigrama())) == menor)
            for (Bigrama *i= k; i<v+n;i++)
        {
            if(tolower(*((i+1)->getBigrama()))< menor1)
            {  
            menor1 = *((i+1)->getBigrama());
            menorp = i;
            }  
        }
            }
    
    }
        }
       for (Bigrama *i= v+n-1; i<=k; i--)
        {
            *i = *(i-1);
            *k= *menorp;
        }
        
    }
    
}

void imprimeBigramas(const Bigrama *v, int n)  {
    cout << "Lista de " << n << " bigramas:" <<endl;
    for (int i=0; i<n; i++)
        cout << v[i].getBigrama() << "-" << v[i].getFrecuencia()<< ", "; // << endl;
}

void sumaBigramas( Bigrama *v1, int nv1, Bigrama *v2, int nv2, Bigrama *&res, int & nres)  {
    bool repite = false;
    Bigrama *pos = res;
    int n = nres;
    for (Bigrama *k = v1; k< v1+nv1; k++)
    {
        for (Bigrama *p=v2; p< v2+nv2; p++)
        {
            if (*(p->getBigrama()) == *(k->getBigrama()))
                repite = true;
        }
        if (!repite){
           *pos = *k;
           pos++;
           repite = false;
           nres++;
        }
    }
    
}


